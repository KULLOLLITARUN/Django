from django.db import models

# Create your models here.
class category(models.Model):
    name=models.CharField(max_length=255)
    def __str__(self):  #to display the name instead of the category object in category table
        return self.name
    
    @staticmethod
    def get_all_categories():
        return category.objects.all()
    """
        This method is used to get all the categories from the database.
    """