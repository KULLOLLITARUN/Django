from django.contrib import admin
from .models import Info, Menu, Special_Menu, Testimonial, Contact

# Register your models here.
@admin.register(Info)
class InfoAdmin(admin.ModelAdmin):
    list_display = ['company_name', 'location', 'phone', 'open_hours']

@admin.register(Menu)
class MenuAdmin(admin.ModelAdmin):
    list_display = ['name', 'price']

@admin.register(Special_Menu)
class Special_MenuAdmin(admin.ModelAdmin):
    list_display = ['name', 'price']

@admin.register(Testimonial)
class TestimonialAdmin(admin.ModelAdmin):
    list_display = ['name', 'review']  # Include review in the display

admin.site.register(Contact)
