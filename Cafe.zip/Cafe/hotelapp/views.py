from django.shortcuts import render
from .models import Info
from .models import Menu
from .models import Special_Menu
from .models import Testimonial
from .models import Contact
# from .models import Booking

# Create your views here.
def index(request):
    info = Info.objects.first()
    menu = Menu.objects.all()
    special_menu=Special_Menu.objects.all()
    context = {
        'info': info,
        'menu': menu,
        'special_menu': special_menu
    }
    return render(request, 'index.html', context)

def full_menu(request):
    menus = Menu.objects.all()
    context = {
        'menus': menus
    }
    return render(request, 'full_menu.html', context)

def special_menu(request):
    special_menu=Special_Menu.objects.all()
    context={
        'special':special_menu
    }
    return render(request,'special_menu.html',context)

def testimonial(request):
    testimonials = Testimonial.objects.all()
    print("Fetched Testimonials:", testimonials)  # Debugging line
    context = {
        'reviews': testimonials
    }
    return render(request, 'customers.html', context)

from django.shortcuts import render
from .models import Menu, Special_Menu  # Ensure you import your models

def order(request):
    menus = Menu.objects.all()  # Fetch all menu items
    special_menus = Special_Menu.objects.all()  # Fetch all special menu items
    context = {
        'menus': menus,
        'special_menus': special_menus,
    }
    return render(request, 'order.html', context)

def order_success(request):
    return render(request, 'order_success.html')

# myapp/views.py
from django.shortcuts import render, redirect
from .forms import ContactForm
from django.shortcuts import render, redirect
from .forms import ContactForm

def contact_view(request):
    if request.method == 'POST':
        print("Request data:", request.POST)  # Log the request data
        form = ContactForm(request.POST)
        
        if form.is_valid():
            # Get the cleaned data
            contact_data = form.cleaned_data
            
            # Directly use the booking_datetime from the cleaned data
            booking_datetime = contact_data['booking_datetime']
            
            # Create a new Contact instance
            contact = Contact(
                first_name=contact_data['first_name'],
                last_name=contact_data['last_name'],
                email=contact_data['email'],
                phone=contact_data['phone'],
                booking_datetime=booking_datetime  # Use the aware datetime directly
            )
            
            # Save the instance to the database
            contact.save()
            print("Form saved successfully")  # Log successful save
            return redirect('contact-success')  # Ensure this URL is defined
        else:
            print("Form errors:", form.errors)  # Log form errors to the console
    else:
        form = ContactForm()

    return render(request, 'contact.html', {'form': form})

from django.shortcuts import render

def contact_success(request):
    return render(request, 'contact_success.html')
