from django.contrib import admin
from django.urls import path
from . import views

urlpatterns = [
    path('',views.index , name='home'),
    # path('landing/',views.landing , name='landing'),
    path('full-menu/', views.full_menu, name='full-menu'),
    path('special-menu/', views.special_menu, name='special-menu'),
    path('testimonials/', views.testimonial, name='testimonial'),
    path('order/', views.order, name='order'),
    path('order-success/', views.order_success, name='order-success'),
    path('contact/', views.contact_view, name='contact'),
    path('contact-success/', views.contact_success, name='contact-success'),

    # path('contact-success/', views.success, name='contact-success'),
]