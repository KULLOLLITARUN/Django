Pillow is used to read images.
we pillow to upload  images.